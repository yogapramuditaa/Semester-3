
package library;


public class LibraryDemo {
    public static void main(String[] args) {
        Car cr1 = new Car();
        cr1.NamaMobil();
        cr1.tahunpembuatan();
        System.out.println("\nNama Mobil : " + cr1.NamaMobil + 
                            "\nTahun Pembuatan : " + cr1.tahunpembuatan() + 
                            "\nBuatan : " + cr1.Buatan);
        
        Car cr2 = new Car();
        cr2.NamaMobil();
        cr2.tahunpembuatan();
        System.out.println("\nNama Mobil : " + cr2.NamaMobil + 
                            "\nTahun Pembuatan : " + cr2.tahunpembuatan() + 
                            "\nBuatan : " + cr2.Buatan);
        
        Car cr3 = new Car();
        cr3.NamaMobil();
        cr3.tahunpembuatan();
        System.out.println("\nNama Mobil : " + cr3.NamaMobil + 
                            "\nTahun Pembuatan : " + cr3.tahunpembuatan() + 
                            "\nBuatan : " + cr3.Buatan);
        
    }
    
}
