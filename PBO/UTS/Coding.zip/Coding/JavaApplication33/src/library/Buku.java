
package library;
import java.util.Scanner;

public class Buku {
    String Judul;
    static int TahunTerbit;
    static String Pengarang = "Pramudita";
    static int Banyak ;
    
    
    Scanner sc = new Scanner(System.in);
    String Judul(){
        System.out.println("Masukkan Judul Buku : ");
        Judul = sc.nextLine();
        return Judul;
    }
    
    int TahunTerbit() {
        System.out.println("Masukkan Tahun Penerbitan : ");
        TahunTerbit = sc.nextInt();
        return TahunTerbit;
    }
    
    int Banyak() {
        System.out.println("Masukkan Banyak Buku : ");
        TahunTerbit = sc.nextInt();
        return TahunTerbit;
    }
}
