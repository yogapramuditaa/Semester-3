package encapsulation1;
import java.util.Scanner;

public class BukuDemo {

    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        Actor Actor1 = new Actor();
        
        System.out.println("Masukkan Nama Actor : ");
        Actor1.setnama(sc.nextLine());
        
        System.out.println("Masukkan Nama Film : ");
        Actor1.setfilm(sc.nextLine());
   
        System.out.println("Masukkan Usia Actor : ");
        Actor1.setusia(sc.nextInt());
        
        System.out.println("\nNama Actor : " + Actor1.getnama() +
                            "\nNama Film : " + Actor1.getfilm() +
                            "\nUsia Actor : " + Actor1.getusia());
    }
    
}
