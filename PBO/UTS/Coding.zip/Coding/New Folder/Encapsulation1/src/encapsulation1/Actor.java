
package encapsulation1;

public class Actor {
    private String nama;
    private String film;
    private int usia;
    
    public void setnama(String nama){
        this.nama = nama ;
    }
    
    public String getnama(){
        return nama;
    }
    
    public void setfilm(String film){
        this.film = film;
    }
    
    public String getfilm(){
        return film;
    }
    
    public void setusia(int usia) {
        this.usia = usia;
    }
    
    public int getusia(){
        return usia;
    }
    
}
