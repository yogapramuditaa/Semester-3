
package encapsulation;
import java.util.Scanner;

public class MobilDemo {
    static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        MobilBalap MobilBalap1 = new MobilBalap();
        
        System.out.println("Masukkan Mobil Balap : ");
        MobilBalap1.setmobil(sc.nextLine);
        
        System.out.println("Masukkan Jenis Mobil : ");
        MobilBalap1.setjenis(sc.nextLine);
        
        System.out.println("Masukkan Kecepatan : ");
        MobilBalap1.setkecepatan(sc.nextLine);
        
        System.out.println("\nNama Mobil Balap : " + MobilBalap1.getmobil() +
                            "\nMasukkan Jenis Mobil : " + MobilBalap1.getjenis() +
                            "\nMasukkan Kecepatan : " + MobilBalap1.getkecepatan());
      
    }
}
