
package encapsulation;

public class MobilBalap {
    private String mobil;
    private String jenis;
    private int kecepatan;
    
    public void setmobil(String mobil){
        this.mobil = mobil;
    }
    
    public String getmobil(){
        return mobil;
    }
    
    public void setjenis(String jenis){
        this.jenis = jenis;
    }
    
    public String getjenis(){
        return jenis;
    }
    
    public void setkecepatan(int kecepatan) {
        this.kecepatan = kecepatan;
    }
    
    public int getkecepatan(){
        return kecepatan;
    }
    
}
