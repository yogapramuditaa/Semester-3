
package paket1;
public class akses1 {
    int jam = 7;
    int menit = 40;
    
}
