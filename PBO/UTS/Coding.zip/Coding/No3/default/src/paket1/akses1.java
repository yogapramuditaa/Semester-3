package paket1;
public class akses1 {
    int jam = 3;
    int menit = 50;
    
}
//Membuat variabel di kelas akses 1
