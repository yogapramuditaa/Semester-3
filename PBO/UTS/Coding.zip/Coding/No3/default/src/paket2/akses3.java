//Berbeda Paket
package paket2;
import paket1.akses1;

public class akses3 {
    public static void main(String[] args) {
        akses1 a = new akses1();
        System.out.println(a.jam);
        System.out.println(a.menit);
    }
}

