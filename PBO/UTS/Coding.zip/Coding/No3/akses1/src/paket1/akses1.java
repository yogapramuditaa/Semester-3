

package paket1;
public class akses1 {
    //Membuat public variabel
    public int jam = 10;
    public int menit = 30;

    public static void main(String[] args) {
        akses1 a = new akses1();
        System.out.println(a.jam);
        System.out.println(a.menit);
        
    }
    
}
