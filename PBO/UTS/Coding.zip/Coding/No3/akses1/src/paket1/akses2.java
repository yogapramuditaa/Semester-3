//Paket sama
package paket1;

//Kelas Berbeda
public class akses2 {
    public static void main(String[] args) {
    akses1 a = new akses1();        //Membuat Objek
    
        //Memanggil objek tanpa error karena bersifat publik
        System.out.println(a.jam);
        System.out.println(a.menit);
    }
}