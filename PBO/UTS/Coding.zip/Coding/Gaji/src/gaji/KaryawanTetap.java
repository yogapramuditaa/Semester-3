package gaji;
public class KaryawanTetap {
    int gajiPokok=2000000;
    //Membuat gaji Tambahan
    int gajiLemburStaff = 30000;
    int gajiLemburSuper = 40000;
    int gajiManageSuper = 60000;
    int gajiLemburManager = 50000;
    int gajiProjectManager = 1000000;
    int gajiManagerSu = 100000;
    int gajiManagerSt = 60000;
    
    //untuk mengatur berapa lama lembur, memanage dan project
    int lemburStaff;
    int lemburSuper, manageSuper;
    int lemburManager, projectManager, ManageManagerSu, ManageManagerSt;
    
    //Staff
    public void setLemburStaff(int lemburStaff) {
        this.lemburStaff = lemburStaff;
    }
    public int getLemburStaff() {
        return lemburStaff*gajiLemburStaff;
    }
    public int TotalGajiStaff() {
        int ts = gajiPokok + getLemburStaff();
        return ts;
    }
    
    //Supervisor
    public void setLemburSuper(int lemburSuper) {
        this.lemburSuper = lemburSuper;
    }
    public int getLemburSuper() {
        return lemburSuper*gajiLemburSuper;
    }
    public void setManageSuper(int manageSuper) {
        this.manageSuper = manageSuper;
    }
    public int getManageSuper() {
        return manageSuper * gajiManageSuper;
    }
    public int TotalGajiSuper() {
        int tss = gajiPokok + getLemburSuper() + getManageSuper();
        return tss;
    }
    
    //Manager
    public void setLemburManager(int lemburManager) {
        this.lemburManager = lemburManager;
      }
    public int getLemburManager() {
        return lemburManager * gajiLemburManager;
    }
    public void setProjectManager(int projectManager) {
        this.projectManager = projectManager;
    }
    public int getProjectManager() {
        return projectManager * gajiProjectManager;
    }
    public void setManageManagerSu(int ManageManagerSu) {
        this.ManageManagerSu = ManageManagerSu;
    }
    public int getManageManagerSu() {
        return ManageManagerSu * gajiManagerSu;
    }
    public void setManageManagerSt(int ManageManagerSt){
        this.ManageManagerSt = ManageManagerSt;
    }
    public int getManageManagerSt(){
        return ManageManagerSt * gajiManagerSt;
    } 
    public int TotalGajiManager(){
        int tm = gajiPokok + getLemburManager() + getProjectManager() + 
                getManageManagerSu() + getManageManagerSt();
        return tm;
    }
     
}
