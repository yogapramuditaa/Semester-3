
package gaji;

public class Main {
     public static void main(String[] args) {
        KaryawanTetap Kt = new KaryawanTetap();
        //Staff
        Kt.setLemburStaff(5);
        //Supervisor
        Kt.setLemburSuper(10);
        Kt.setManageSuper(12);
        //Manager
        Kt.setLemburManager(15);
        Kt.setProjectManager(2);
        Kt.setManageManagerSu(3);
        Kt.setManageManagerSt(7);
        
        KaryawanKontrak Kk = new KaryawanKontrak();
        Kk.setKehadiran(14);
        
        System.out.println("Gaji Total Staff : Rp " + Kt.TotalGajiStaff() + "\n" +
                            "Gaji Total Manager : Rp " + Kt.TotalGajiManager() + "\n" +
                            "Gaji Total Supervisor : Rp " + Kt.TotalGajiSuper() + "\n" +
                            "Gaji Total Karyawan Kontrak : Rp " + Kk.TotalGajiKontrak());
        
    }
    
}
