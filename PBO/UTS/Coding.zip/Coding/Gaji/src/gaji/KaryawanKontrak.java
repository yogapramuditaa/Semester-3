
package gaji;

public class KaryawanKontrak {
    int upahKehadiran = 75000;
    int Kehadiran;
    
    public void setKehadiran(int Kehadiran){
        this.Kehadiran = Kehadiran;
    }
    public int getKehadiran(){
        return Kehadiran;
    }
    public int TotalGajiKontrak(){
        int tk = upahKehadiran * getKehadiran();
        return tk;
    }
    
}
