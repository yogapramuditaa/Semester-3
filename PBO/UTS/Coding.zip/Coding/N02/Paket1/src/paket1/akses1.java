

package paket1;

//Membuat Private variable pada kelas akses1
public class akses1 {
    private final int jam = 9;
    private final int menit = 15;
    
    public int getJam() {
        return jam;
    }
    
    public static void main(String[] args) {
        akses1 data = new akses1();
        data.getJam();
        //Memanggil tanpa terjadinya error
        System.out.println(data.jam);
        System.out.println(data.menit);
    }
}
