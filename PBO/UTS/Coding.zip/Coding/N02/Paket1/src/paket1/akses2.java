//Yoga Pramudita
//l200200182

//Membuat kelas berbeda tetapi dengan paket yang sama
package paket1;
public class akses2 {
    public static void main(String[] args) {
        
        akses1 a = new akses1();
        System.out.println(a.jam);
        System.out.println(a.menit);
    }
}
