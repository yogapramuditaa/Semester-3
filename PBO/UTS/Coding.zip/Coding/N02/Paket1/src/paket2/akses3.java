
package paket2;
import paket1.akses1;

public class akses3 extends akses1 {
    public static void main(String[] args) {
        //Dengan menggunakan subclass dari beda paket
        akses3 a = new akses3();
        System.out.println(a.jam);
        System.out.println(a.menit);
    }
}
