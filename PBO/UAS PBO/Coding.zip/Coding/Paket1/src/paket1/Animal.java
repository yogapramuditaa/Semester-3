
package paket1;

public class Animal {
    public String nama;
    public String makan;
    public String habitat;
    
public String Kucing(String nama) {
    this.makan = makan;
    return this.nama;    
}

public String Kucing(String makan, String habitat){
    this.makan = makan;
    this.habitat = habitat;
    return this.makan + this.habitat;
    }
}