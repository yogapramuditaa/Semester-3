
package paket1;

public class Cat extends Animal {
    
    @Override
    public String Kucing(String nama){
        this.nama = nama;
        return this.nama;
    }
    
    @Override
    public String Kucing(String makan, String habitat){
        this.makan = makan;
        this.habitat = habitat;
        return this.makan + this.habitat;
    }
    
    public static void main(String[] args) {
        Cat a = new Cat();
        System.out.println("Nama : " + a.Kucing("Common"));
        System.out.println("Makan dan Tinggal : " + a.Kucing("Whiskas dan Rumah"));

    }    
}
