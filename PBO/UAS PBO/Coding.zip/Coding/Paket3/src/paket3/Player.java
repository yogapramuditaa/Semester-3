
package paket3;


public class Player implements Walk {

    @Override
    public void SpeedUp() {
        System.out.println("Player Can Move");
    }

    @Override
    public void Move() {
        System.out.println("Move" + action [0] + "\n" +
                            "Move" + action [1] + "\n" +
                            "Move" + action [2] + "\n" +
                            "Move" + action [3]);
    }
    
    public static void main(String[] args) {
       Player a = new Player();
       a.SpeedUp();
       a.Move();
    }
}
