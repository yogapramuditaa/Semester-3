
package paket3;


interface Walk extends Action{
    String [] action = {"forward", "backward", "left", "right"};
    public void SpeedUp();
 
}
