
package paket3;
interface Action{
    public void Move();
}

