
package paket4;


public class DemoOuter {

    
    public static void main(String[] args) {
        Outer outerObj = new Outer();
        Outer.Inner innerObj = outerObj.new Inner();
        Outer.Nested nestedObj = new Outer.Nested();
        
        System.out.println(outerObj.code);
        System.out.println(innerObj.inner);
        System.out.println(nestedObj.nested);
    }
}
