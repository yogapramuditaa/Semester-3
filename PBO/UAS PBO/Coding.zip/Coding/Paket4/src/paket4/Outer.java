
package paket4;

public class Outer {
    public String code = "NIM : L200200182";
    public static int count;
    
    Outer(){
        count += 1;
        System.out.println("Outer: " + count);
    }
    
    class Inner{
        String inner = "this is Inner Class";
        String inner(){
        return code;
        }
    }
    static class Nested{
        String nested = "this is Nested Class";
        int nested(){
        return count;
        }
    }
    
}
