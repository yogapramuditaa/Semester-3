
package Paket2;


public abstract class Member {
    public abstract String Presence();
    public abstract String Information();
    
    public String Park(){
        return Presence() + Information();
    }
}
