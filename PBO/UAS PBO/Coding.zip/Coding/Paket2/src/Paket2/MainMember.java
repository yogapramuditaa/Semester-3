package Paket2;

public class MainMember extends Member {
    
    @Override
    public String Presence() {
        String Presence = "Hadir, ";
        return Presence;
    }

    @Override
    public String Information() {
        String Information = "Yoga Pramudita";
        return Information;
    }
    
     public static void main(String[] args) {
        MainMember a = new MainMember();
        System.out.println(a.Park());
    }
}
