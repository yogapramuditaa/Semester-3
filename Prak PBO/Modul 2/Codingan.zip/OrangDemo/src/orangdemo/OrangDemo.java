
package orangdemo;

public class OrangDemo {

    public static void main(String[] args) {
      System.out.println("Data dibawah adalah Dosen");
      Orang dosen = new Orang();
      dosen.tampilkanNama("Agus");
      dosen.tampilkanNIK(29740938);
      dosen.tampilkanPendidikan("Psikologi");
      dosen.tampilkanTglLahir("12 September 1990");
      
      System.out.println("-------------------");
      
      System.out.println("Data dibawah adalah Karyawan");
      Orang karyawan = new Orang();
      karyawan.tampilkanNama("Doni");
      karyawan.tampilkanAlamat("Rembang");
      karyawan.tampilkanjabatan("HRD");
      karyawan.tampilkanGaji(10000000);
      
      System.out.println("-------------------");
      
      System.out.println("Data dibawah adalah Mahasiswa");
      Orang mahasiswa = new Orang();
      mahasiswa.tampilkanNama("Doni");
      mahasiswa.tampilkanNIM("L200200182");
      mahasiswa.tampilkanAlamat("Rembang");
      mahasiswa.tampilkanSemester(3);
     
    }
    
    
    
}
