
package orangdemo;

public class Orang {
    String Nama, Pendidikan, TanggalLahir, Alamat, Jabatan, NIM;
    int NIK, Semester;
    double Gaji;
    
    void tampilkanNama(String nama) {
        Nama = nama;
        System.out.println("Nama: " + this.Nama);
    }
    
    void tampilkanPendidikan(String pendidikan) {
         Pendidikan = pendidikan;
        System.out.println("Pendidikan: " + this.Pendidikan);
    }
    
    void tampilkanTglLahir(String tgl) {
         TanggalLahir = tgl;
        System.out.println("Tanggal Lahir: " + this.TanggalLahir);
    }
    
    void tampilkanNIK(int nik) {
         NIK = nik;
        System.out.println("NIK: " + this.NIK);
    }
    
    void tampilkanAlamat(String alamat) {
         Alamat = alamat;
        System.out.println("Alamat: " + this.Alamat);
    }
    
    void tampilkanjabatan(String jabatan) {
         Jabatan = jabatan;
        System.out.println("Jabatan: " + this.Jabatan);
    }
    
    void tampilkanNIM(String nim) {
         NIM = nim;
        System.out.println("NIM: " + this.NIM);
    }
    
    void tampilkanSemester(int semester) {
         Semester = semester;
        System.out.println("Semester: " + this.Semester);
    }
    
    void tampilkanGaji(double gaji) {
         this.Gaji = gaji;
        System.out.println("Pendidikan: " + this.Gaji);
    }
}
