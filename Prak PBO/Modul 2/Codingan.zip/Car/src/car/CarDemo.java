
package car;

public class CarDemo {
    public static void main(String[] args){
        Car car1 = new Car();
        
        car1.changeCadence(70);
        car1.SpeedUp(40);
        car1.changeGear(3);
        car1.printInfo();
        
        System.out.println("------------");
        
        Car car2 = new Car();
        
        car2.changeCadence(50);
        car2.SpeedUp(20);
        car2.changeGear(2);
        car2.printInfo();
        
        
    }
    
}
