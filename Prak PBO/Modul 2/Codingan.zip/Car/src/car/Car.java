
package car;


public class Car {
    int changeCadence = 0;
    int speedUp = 0;
    int changeGear = 1;
    
    void changeCadence(int ubah){
        this.changeCadence = ubah;
    }
    
    void SpeedUp (int tambah){
        this.speedUp = tambah;
    }
    
    void changeGear (int ubahgear){
        this.changeGear = ubahgear;
    }
    
    void printInfo(){
        System.out.println(
                "Cadence = " + changeCadence + "\n" +
                "Speed = " + speedUp + "\n" +
                "gear = " + changeGear);

    
    }  
}
