
package kucingdemo;

public class Kucing {
    String warna;
    int umur;
    
    void umur(int beriUmur){
        this.umur = beriUmur;
    }
    
    void warna(String beriWarna){
        this.warna = beriWarna;
    }
    
    void Meong(){
        System.out.println(
              "Umur: " + umur + "Tahun" + "\n" +
              "Warna: " + warna + ""
        );
    }
    
}
