
package kucingdemo;

public class KucingDemo {

    
    public static void main(String[] args) {
      Kucing dome = new Kucing();
      dome.umur(1);
      dome.warna("orange");
      dome.Meong();
    }
    
}
