
package hewan;


public class HewanDemo {

    
    public static void main(String[] args) {
        
        Hewan jenis1 = new Hewan();
        jenis1.beriNama("Ayam");
        jenis1.beriJumlahKaki(2);
        jenis1.beriMakanan("Biji");
        jenis1.beriTypeHewan("Omnivora");
        jenis1.infoHewan();
        
        System.out.println();
        
        Hewan jenis2 = new Hewan();
        jenis2.beriNama("Kambing");
        jenis2.beriJumlahKaki(4);
        jenis2.beriMakanan("Rumput");
        jenis2.beriTypeHewan("Herbivora");
        jenis2.infoHewan();
    }
    
}
