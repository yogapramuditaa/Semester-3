
package hewan;


public class Hewan {
    String Nama, Makanan, TypeHewan;
    int JumlahKaki;
    
    void beriNama(String Name){
        this.Nama = Name;
    }
    
    void beriMakanan(String Food){
        this.Makanan = Food;
    }
    
    void beriTypeHewan(String Type){
        this.TypeHewan = Type;
    }
    
    void beriJumlahKaki(int Foot){
        this.JumlahKaki = Foot;
    }
    
    void infoHewan(){
        System.out.println(
            "Nama Hewan: " + this.Nama + "\n" +
            "Jumlah Kaki: " + this.JumlahKaki + "\n" +
            "Makanan: " + this.Makanan + "\n" +
            "Type Hewan: " + TypeHewan);
    }
}
