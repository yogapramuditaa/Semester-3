package rotidemo;

public class Roti {
    //Membuat variabel
    String nama;
    String warna;
    String rasa;
    int berat;
    double harga;
    
    void beriWarna(String warnaRoti){
        warna = warnaRoti;
    }
    
    void beriRasa(String rasaRoti){
        rasa = rasaRoti;
    }
    
    void timbangBerat(int beratRoti){
        berat = beratRoti;
    }
    
    void hargaJual(double hargaRoti){
        harga = hargaRoti;
    }
    
    void infoRoti(){
        System.out.println(
                "Nama: " + nama + "\n" +
                "Rasa: " + rasa + "\n" +
                "Berat: " + berat + "\n" +
                "Harga: " + harga + "\n");
    }
    }