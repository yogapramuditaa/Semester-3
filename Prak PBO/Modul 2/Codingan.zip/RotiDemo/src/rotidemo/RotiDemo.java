
package rotidemo;

public class RotiDemo {
    public static void main(String[] args) throws Exception {
        Roti jenis1 = new Roti();
        jenis1.nama = "Donat";
        jenis1.rasa = "coklat";
        jenis1.berat = 30;
        jenis1.harga = 2500;
        jenis1.infoRoti();
        
        System.out.println("------------");
        
        Roti jenis2 = new Roti();
        jenis2.nama = "Bakar";
        jenis2.rasa = "keju";
        jenis2.berat = 30;
        jenis2.harga = 2500;
        jenis2.infoRoti();
        
        System.out.println("------------");
        
        Roti jenis3 = new Roti();
        jenis3.nama = "Isi";
        jenis3.rasa = "vaila";
        jenis3.berat = 30;
        jenis3.harga = 2500;
        jenis3.infoRoti();
        
    }
    
}
