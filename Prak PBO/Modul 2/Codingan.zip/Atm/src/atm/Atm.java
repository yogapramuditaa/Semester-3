
package atm;
import java.util.Scanner;

public class Atm {
    String nama, norekening;
    int saldo,tabung, tarik, menu, transfer;
    Scanner masukan = new Scanner(System.in);
    
    void pilihmenu(){
    while (true){
        System.out.println("Pilih Menu: " + "\n"
    + "1. Menabung" + "\n"
    + "2. Tarik Tunai" + "\n"
    + "3. Transfer" + "\n"
    + "4. Info Atm Anda" + "\n"
    + "5. Keluar");
    menu = masukan.nextInt();
    
    if (menu == 1){
        this.menabung();
    }
    else if (menu == 2){
        this.menarik();
    }
    else if (menu == 3){
        this.transfer();
    }
    else if (menu == 4){
        this.infoatm();
    }
    else if (menu == 5){
        System.out.println("Anda Berhasil Keluar dari Atm");
                break;
    }
    else{
        System.out.println("Menu Salah");
    }
    
    //#########################################
    
    void inputnama() {
        System.out.println("Masukkan Nama : ");
        nama = masukan.nextLine();
    }
    void input_norekening(){
        System.out.println("Masukkan No Rekening Anda : ");
        norekening = masukan.nextLine();
    }
    void cek_saldo(){
        System.out.println("Saldo Anda : ");
        saldo = masukan.nextInt();
    }
    void menabung(){
        System.out.println("Masukkan Nominal Tabung: ");
        tabung = masukan.nextInt();
        saldo = saldo + tabung;
    }
    void menarik(){
        System.out.println("Masukkan Nominal Tarik Tunai: ");
                tarik = masukan.nextInt();
                saldo = saldo - transfer;
    }
    void transfer(){
        System.out.println("Masukkan Nominal Transfer: ");
        transfer = masukan.nextInt();
        saldo = saldo - transfer;
    }
    void infoatm(){
        System.out.println(
        "Nama: " + nama + "\n" +
        "Saldo: " + saldo + "\n");
        System.out.println("##############");
    }
    }

    void inputnama() {
        System.out.println("Masukkan Nama : ");
        nama = masukan.nextLine();
    }

   

    
    

    