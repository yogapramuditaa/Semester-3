
package atm;


public class AtmDemo {
    public static void main(String[] args) {
    Atm orangnya = new Atm();
    orangnya.inputnama();
    orangnya.input_norekening();
    orangnya.pilihmenu();
    }
}
