
package Tugas9_4;
public class PrismaSegitiga extends BangunRuang{
    int alas = 3;
    int tinggisegitiga = 4;
    int tinggiprisma = 7;

    @Override
    public int Volume() {
        return (int) ((alas * tinggisegitiga * 0.5) * tinggiprisma);
    }

    @Override
    public int LuasPermukaan() {
        int luasalas = (int) (0.5) *alas * tinggisegitiga;
        int kelilingalas = (int) Math.sqrt(Math.pow(alas, 2) + Math.pow(tinggisegitiga, 2));
        int kelilingsegitiga = (int) alas + tinggisegitiga + kelilingalas;
        return (2 * luasalas) + (kelilingsegitiga * tinggiprisma);
    }
    
    public void show() {
        System.out.println("Volume Prisma Segitiga: " + Volume() + "\n" +
                            "Luas Permukaan Prisma Segitiga: " + LuasPermukaan());
    }
    public static void main(String[] args) {
        PrismaSegitiga e = new PrismaSegitiga();
        e.show();
    }
    
    
}
