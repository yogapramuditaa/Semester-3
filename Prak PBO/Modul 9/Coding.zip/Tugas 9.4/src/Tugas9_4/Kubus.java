
package Tugas9_4;
public class Kubus extends BangunRuang{
    public int sisi;

    @Override
    public int Volume() {
       return sisi * sisi * sisi;
    }

    @Override
    public int LuasPermukaan() {
        return 6 * sisi * sisi;
    }
    
    public void show() {
        System.out.println("Volume Kubus: " + Volume() + "\n" +
                            "Luas Permukaan Kubus: " + LuasPermukaan());
    }
    public static void main(String[] args) {
        Kubus b = new Kubus();
        b.show();
    }
    
}
