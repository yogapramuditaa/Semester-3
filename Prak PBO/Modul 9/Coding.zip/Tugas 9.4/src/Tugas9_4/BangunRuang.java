
package Tugas9_4;

public abstract class BangunRuang {
    public abstract int Volume();
    public abstract int LuasPermukaan();
    
    public int getVolume() {
        return Volume();
    }
    
    public int getLuasPermukaan() {
        return LuasPermukaan();
    }
    
}
