
package Tugas9_4;
public class Bola extends BangunRuang{
    final double pi = 3.14;
    int jarijari = 16;

    @Override
    public int Volume() {
        return (int) (4/3 * pi * jarijari * jarijari * jarijari);
    }

    @Override
    public int LuasPermukaan() {
        return (int) (4 * jarijari * jarijari);
    }
    
    public void show() {
        System.out.println("Volume Bola: " + Volume() + "\n" +
                            "Luas Permukaan Bola: " + LuasPermukaan());
    }
    public static void main(String[] args) {
        Bola c = new Bola();
        c.show();
    }
    
}
