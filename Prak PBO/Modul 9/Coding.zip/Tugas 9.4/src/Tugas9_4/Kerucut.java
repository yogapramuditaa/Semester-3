
package Tugas9_4;
public class Kerucut extends BangunRuang{
    double pi = 3.14;
    int jarijari = 8;
    int tinggi = 14;
    int s = 22;

    @Override
    public int Volume() {
        return (int) (0.33 * pi * jarijari * jarijari * tinggi);
    }

    @Override
    public int LuasPermukaan() {
        int LuasAlas = (int) pi * jarijari * jarijari;
        int LuasSelimut = (int) pi * jarijari * s;
        return LuasAlas + LuasSelimut;
    }
    
    public void show() {
        System.out.println("Volume Kerucut: " + Volume() + "\n" +
                            "Luas Permukaan Kerucut: " + LuasPermukaan());
    }
    public static void main(String[] args) {
        Kerucut d = new Kerucut();
        d.show();
    }
    
}
