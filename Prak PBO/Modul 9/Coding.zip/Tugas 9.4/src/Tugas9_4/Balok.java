package Tugas9_4;
public class Balok extends BangunRuang{
    private int panjang = 5, luas = 5, tinggi = 5;

    @Override
    public int Volume() {
        return panjang * luas * tinggi;
    }

    @Override
    public int LuasPermukaan() {
        return 2 * (panjang * luas + panjang * tinggi + luas * tinggi);
    }
    
    public void show() {
        System.out.println("Volume Balok: " + Volume() + "\n" +
                            "Luas Permukaan Balok: " + LuasPermukaan());
    }
    
     public static void main(String[] args) {
        Balok a = new Balok();
        a.show();
    }
    
}
