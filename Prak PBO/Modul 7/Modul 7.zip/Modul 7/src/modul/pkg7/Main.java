
package modul.pkg7;


public class Main {
    public static void main(String[] args) {
        //Membuat objek dari kelas Manager.java
        Manager m = new Manager();
        
        //Memanggil setter
        m.setNama("Yoga pramudita");
        m.setGaji(5000000);
        m.setJamKerja(8.5f);
        m.setUsia(20);
        
        //Memanggil getter
        System.out.println("Nama : " + m.getNama() + "\n" +
                           "Usia : " + m.getUsia() + "\n" +
                           "Jam Kerja : " + m.jamKerja() + "\n" +
                           "Gaji Karyawan : " + m.getGaji() + "\n" +
                           "Gaji Manager : " + m.getGajiManager());
    }
    
}
