
package modul.pkg7;

public class Karyawan {
    private String nama;
    private float gaji;
    private int usia;
    
    //Membuat setter dan getter nama
    public String getNama() {
        return nama;
    }
    
    public void setNama(String nama) {
        this.nama = nama;
    }
    
    //Membuat setter dan getter gaji
    public float getGaji() {
        return gaji;
    }
    
    public void setGaji(float gaji) {
        this.gaji = gaji;
    }
    
    //Membuat setter dan getter gaji
    public int getUsia() {
        return usia;
    }
    
    public void setUsia(int usia) {
        this.usia = usia;
    }
    
}
