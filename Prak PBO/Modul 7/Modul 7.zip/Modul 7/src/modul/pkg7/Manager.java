
package modul.pkg7;


public class Manager extends Karyawan {
    private float jamKerja = 7.5f;
    
    public float jamKerja() {
        return jamKerja;
    }
    
    public void setJamKerja(float jamKerja) {
        this.jamKerja = jamKerja;
    }
    
    public float getGajiManager() {
        int getGaji;
        return getGaji = 9000000;
    }
    
    
}
