
package Paket1;

public class NestedClass {
    String nama = "Yoga Pramudita";
    String nim = "L200200182";
    
    public void.printNama(){
        System.out.println(nama + ":" + nim);
    }
    
    static class StaticNestedClass(){
        static String jurusan = "Teknik Informatika";
        public void showNama(){
            NestedClass a = new NestedClass();
            a.printnama();
        }
}
class InnerClass{
    public void showJurusan() {
        System.out.println("Jurusan : " + NestedClass.StaticNestedClass.jurusan);
    }
}   


