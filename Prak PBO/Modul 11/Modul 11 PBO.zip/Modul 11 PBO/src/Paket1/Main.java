package Paket1;

public class Main {
    public static void main(String[] args) {
        NestedClass a = new NestedClass();
        NestedClass.StaticNestedClass b = new NestedClass.StaticNestedClass();
        NestedClass.InnerClass c = a.new InnerClass();
        
        b.showNama();
        c.showJurusan;
    }
    
}
