
package defaultmodifier;


public class DefaultModifierDemo {
    public static void main(String[] args) {
        DefaultModifier coba = new DefaultModifier();
        coba.jumlah();
       
    }
    
}
