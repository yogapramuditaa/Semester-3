
package tugas4.pkg2;
import pkg4.PublicModifier;


public class Tugas42 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
