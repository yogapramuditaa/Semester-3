
package pkg4;

class PublicModifier {
    public int a = 2;
    public int b = 7;
    public int c = 6;
    
    public void kali(){
        int d = a*b*c;
        System.out.println("Hasil Kali :" + d);
    }
    
    void tambah(){
        int d = a+b+c;
        System.out.println("Hasil pertambahan :" + d);
    }
    
    void kurang(){
        int d = a-b-c;
        System.out.println("Hasil pertambahan :" + d);
    }
    
    void bagi(){
        int d = a/b/c;
        System.out.println("Hasil pertambahan :" + d);
    }
    
    void rata(){
        int d = (a+b+c)/3;
        System.out.println("Hasil pertambahan :" + d);
    }
           
   
}
