
package pkg4;


public class PublicModifierDemo {
    public static void main(String[] args) {
        PublicModifier i = new PublicModifier();
        
        i.kali();
        i.bagi();
        i.kurang();
        i.rata();
    }
    
}
