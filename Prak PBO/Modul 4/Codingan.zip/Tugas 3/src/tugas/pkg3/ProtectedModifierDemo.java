
package tugas.pkg3;


public class ProtectedModifierDemo {
    public static void main(String[] args) {
        ProtectedModifier i = new ProtectedModifier();
        i.printInfo();
        i.sendMessage();
    }
    
}
