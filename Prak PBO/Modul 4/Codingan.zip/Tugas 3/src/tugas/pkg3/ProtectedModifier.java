
package tugas.pkg3;

class ProtectedModifier {
    protected void printInfo(){
        System.out.println("Protected Modifier");
    }
    
    protected void sendMessage(){
        System.out.println("Ini adalah pesan");
    }
    
    
}
