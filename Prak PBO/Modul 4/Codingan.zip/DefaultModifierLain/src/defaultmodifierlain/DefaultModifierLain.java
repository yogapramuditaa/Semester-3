
package defaultmodifierlain;
import defaultmodifier.DefaultModifier;

public class DefaultModifierLain {
    public static void main(String[] args) {
       DefaultModifier dm = new DefaultModifier();
       dm.jumlah();
    }
    
}
