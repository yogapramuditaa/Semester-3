
package privatemodifier;

public class PrivateModifierDemo {
    public static void main(String[] args){
    PrivateModifier pv = new PrivateModifier();
    pv.nama = ("Yoga")
    }
    
}
