
package privatemodifier;

public class PrivateModifier {
    private String nama;
    private int umur;

   
    public void printInfo() {
        System.out.println("Private modifier");
    }
}
