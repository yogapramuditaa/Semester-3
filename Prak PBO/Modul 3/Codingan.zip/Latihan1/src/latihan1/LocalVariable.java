
package latihan1;


public class LocalVariable {
    int usiaku;
    public void hitungUsia(){
        //variabel lokal
        int usia = 0;
        int tahunSekarang = 2019;
        int tahunLahir = 1993;
        
        usia = tahunSekarang - tahunLahir;
        
        System.out.println("Usia Saya : " + usia);
    }
    
    public void beratBadan(){
        int beratLahir = 3;
        int beratBadan = beratLahir + usiaku/2;
        
        System.out.println("Berat saya : " + beratBadan);
    }
    
    public static void main(String[] args) {
        LocalVariable hasil = new LocalVariable();
        
        hasil.hitungUsia();
        hasil.beratBadan();
    }
    
}
