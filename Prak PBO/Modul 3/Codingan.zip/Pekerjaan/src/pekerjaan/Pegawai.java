
package pekerjaan;


public class Pegawai {
    String nama;
    int nip;
    double gaji;
    
    void beriNama(String namapegawai){
        nama = namapegawai;
    }
    
    void beriNIP(int nippegawai){
        nip = nippegawai;
    }
    
    void beriGaji(double gajipegawai){
        gaji = gajipegawai;
    }
    
    void infoPegawai(){
        System.out.println(
            "Nama : " + nama + "\n" +
            "NIP : " + nip + "\n" +
            "Gaji : " + gaji);
    }
   
    public static void main(String[] args) {
       Pegawai pegawai1 = new Pegawai();
       pegawai1.nama = "Yoga";
       pegawai1.nip = 9584983;
       pegawai1.gaji = 9000000;
       pegawai1.infoPegawai();
       
       System.out.println();
       
       Pegawai pegawai2 = new Pegawai();
       pegawai2.nama = "Pramudita";
       pegawai2.nip = 12939484;
       pegawai2.gaji = 7000000;
       pegawai2.infoPegawai();
       
       System.out.println();
       
       Pegawai pegawai3 = new Pegawai();
       pegawai3.nama = "Uta";
       pegawai3.nip = 6758574;
       pegawai3.gaji = 5000000;
       pegawai3.infoPegawai();
       
       System.out.println();
       
       Pegawai pegawai4 = new Pegawai();
       pegawai4.nama = "Kicen";
       pegawai4.nip = 6575848;
       pegawai4.gaji = 8000000;
       pegawai4.infoPegawai();
       
       System.out.println();
       
       Pegawai pegawai5 = new Pegawai();
       pegawai5.nama = "Elang";
       pegawai5.nip = 17364735;
       pegawai5.gaji = 7000000;
       pegawai5.infoPegawai();
       
       System.out.println();
               
    }
    
}
