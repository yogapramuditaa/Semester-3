
package nilai;


public class Nilai {
    int nilaiUTS;
    int nilaiTugas;
    int nilaiUAS;
    
    public void NilaiMahasiswa(int UTS, int UAS, int Tugas){
        this.nilaiUTS = UTS;
        this.nilaiUAS = UAS;
        this.nilaiTugas = Tugas;
    }
    
    public int nilaiUTS(){
        return this.nilaiUTS;
    }
    public int nilaiTugas(){
        return this.nilaiTugas;
    }
    public int nilaiUAS(){
        return this.nilaiUAS;
    }
    
    public void infoNILAI(){
        System.out.println(
            "UTS : " + nilaiUTS + "\n" +
            "UAS : " + nilaiUAS + "\n" +
            "Tugas : " + nilaiTugas + "\n");
    }

    public void nilaiTOTAL(){
        int nilaisemua = nilaiUTS + nilaiUAS + nilaiTugas/3;
        double nilaiTotal = nilaisemua;
        
        System.out.println("Nilai Total : " + nilaiTotal);
    }
    
    public static void main(String[] args) {
        Nilai nilaiku = new Nilai();
        nilaiku.NilaiMahasiswa(92, 95, 87);
        nilaiku.nilaiUTS();
        nilaiku.nilaiUAS();
        nilaiku.nilaiTugas();
        nilaiku.infoNILAI();
        nilaiku.nilaiTOTAL();
        
    }
    
}
