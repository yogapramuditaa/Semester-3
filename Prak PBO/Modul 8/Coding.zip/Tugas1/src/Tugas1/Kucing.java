
package Tugas1;


public class Kucing extends Pet {
    //overiding terhadap method perilaku pada pet
    @Override
    public String perilaku() {
        return "Menyukai ikan";
    }
    public String suara() {
        return "Miaw..Miaw..Miaw";
    }
}
