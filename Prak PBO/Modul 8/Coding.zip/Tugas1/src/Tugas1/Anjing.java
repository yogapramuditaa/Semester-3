
package Tugas1;


public class Anjing extends Pet {
    //overiding terhadap method perilaku pada pet
    @Override
    public String perilaku() {
        return "Menyukai daging dan tulang";
    }
    public String suara() {
        return "Guk..Guk..Guk..";
    }
}
