
package Tugas1;


public class TestPolymorphism {
    public static void main(String[] args) {
        Kucing p = new Kucing();
        p.beriNama("Badrun");
        System.out.println(p.panggilNama() + "\n" + p.perilaku() + "\n" + p.suara());
        
        Anjing a = new Anjing();
        a.beriNama("Wahyu");
        a.perilaku();
        a.suara();
        System.out.println(a.panggilNama() + "\n" + a.perilaku() + "\n" + a.suara());
    }
    
}
