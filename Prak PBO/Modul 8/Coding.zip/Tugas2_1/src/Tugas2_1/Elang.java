
package Tugas2_1;

public class Elang extends Hewan{
    //overriding jalan dikelas hewan
    @Override
    public void jalan() {
        System.out.println("Terbang");
    }
    //implementasi yang berbeda
    public static void main(String[] args) {
        Elang e = new Elang();
        e.jalan();
    }
}
