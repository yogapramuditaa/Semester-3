
package Tugas2_1;

public class Hewan {
    public void jalan() {
        System.out.println("Hewan bisa berjalan");
    }
}
