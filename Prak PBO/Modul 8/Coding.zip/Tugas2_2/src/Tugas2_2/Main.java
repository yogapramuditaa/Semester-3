package Tugas2_2;

public class Main {
    public static void main(String[] args) {
        CustomerData a = new CustomerData();
        CustomerData customer1 = new CustomerData("Yoga Pramudita", "Rembang", "Mahasiswa", 8, 5000000);
        CustomerData b = new CustomerData();
        CustomerData customer2 = new CustomerData("Badrun", "Bandung", "Aktor", 16, 7000000);
        CustomerData c = new CustomerData();
        CustomerData customer3 = new CustomerData("Soleh", "Boyolali", "Youtuber", 10, 5000000);
        CustomerData ad = new CustomerData();
        CustomerData customer4 = new CustomerData("Mahmud", "Solo", "Mahasiswa", 7, 2000000);
        CustomerData e = new CustomerData();
        CustomerData customer5 = new CustomerData("Kepimn", "Rembang", "Mahasiswa", 2, 1000000);
           
        }
}
    

