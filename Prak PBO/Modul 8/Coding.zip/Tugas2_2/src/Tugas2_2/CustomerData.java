
package Tugas2_2;


public class CustomerData {
    public String nama, alamat, pekerjaan;
    public int gaji, tanggalLahir;
    
    //Optional, agar data customer bervariasi
    public static int jmlCustomer;
    
    //overloading
    CustomerData() {
        CustomerData.jmlCustomer++;
        System.out.println("\nData Customer " + CustomerData.jmlCustomer);
    }
    
    CustomerData(String nama, String alamat, String pekerjaan, int tanggalLahir, int gaji){
        this.nama = nama;
        this.alamat = alamat;
        this.pekerjaan = pekerjaan;
        this.tanggalLahir = tanggalLahir;
        this.gaji = gaji;
        System.out.println("Nama: " + this.nama + "\n" +
                            "Alamat: " + this.alamat + "\n" +
                            "Pekerjaan: " + this.pekerjaan + "\n" +
                            "Tanggal Lahir: " + this.tanggalLahir + "\n" +
                            "Gaji: " + this.gaji + "/Bulan");
    }
    
}
