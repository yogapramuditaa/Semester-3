
package Latihan9_3;

public class Lingkaran extends methodAbstract {
    double pi = 3.14;
    int diameter = 10;
    int jarijari = 5;

    @Override
    public int luas() {
        return (int) (pi * jarijari*jarijari);
    }

    @Override
    public int keliling() {
        return (int) (pi*diameter);
    }
    
    public void show() {
        System.out.println("Luas Lingkaran : " + luas() + "\n" +
                            "Keliling Lingkaran : " + keliling());
    }
    
    public static void main (String[] args) {
        Lingkaran c = new Lingkaran();
        c.show();
    }
    
}
