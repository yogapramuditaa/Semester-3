
package Latihan9_3;


public class PersegiPanjang extends methodAbstract{
    int panjang = 5;
    int lebar = 10;

    @Override
    public int luas() {
        return panjang * lebar;
    }

    @Override
    public int keliling() {
        return 2 * (panjang + lebar);
    }
    public void show() {
        System.out.println("Luas Persegi Panjang : " + luas() + "\n" +
                            "Keliling Persegi Panjang : " + keliling());
    }
    public static void main (String [] args) {
        PersegiPanjang a = new PersegiPanjang();
        a.show();
    }

}
