
package Latihan9_3;


public abstract class methodAbstract {
    public abstract int luas();
    public abstract int keliling();
    
    public int getLuas() {
        return luas();
    }
    public int getKel() {
        return keliling();
    }
}
