
package Latihan9_3;
public class Segitiga extends methodAbstract{
    int alas = 8;
    int tinggi = 14;
    int sisimiring = 14;

    @Override
    public int luas() {
        return (int) (0.5 * alas * tinggi);
    }

    @Override
    public int keliling() {
        return alas + sisimiring * 2;
    }
    
    public void show() {
        System.out.println("Luas Segitiga : " + luas() + "\n" +
                            "Keliling Segitiga : " + keliling());
    }
    
    public static void main (String[] args) {
        Segitiga d = new Segitiga();
        d.show();
    }
    
}
