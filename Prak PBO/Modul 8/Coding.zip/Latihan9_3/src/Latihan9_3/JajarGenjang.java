package Latihan9_3;

public class JajarGenjang extends methodAbstract {
    int sisialas = 5;
    int sisimiring = 4;
    int tinggi = 9;


    @Override
    public int luas() {
        return sisialas * tinggi;
    }

    @Override
    public int keliling() {
        return 2 * (sisialas + sisimiring);
    }
    
    public void show() {
       System.out.println("Luas Jajar Genjang : " + luas() + "\n" +
                            "Keliling Jajaar Genjang : " + keliling()); 
    }
    
    public static void main(String[] args) {
        JajarGenjang b = new JajarGenjang();
        b.show();
    }
    
}
