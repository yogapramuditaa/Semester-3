
package Tugas2_4;

public class BankSyariah extends BankUmum {
    protected int rasioBunga(){
        int bungapertahun = 8;
        System.out.println("Bank Syariah Memiliki Bunga : " + bungapertahun + "%");
        return bungapertahun;
    }
    
}
