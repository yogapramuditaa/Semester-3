package Tugas2_4;
public class Main {
    //Untuk menampilkan output
    public static void main(String[] args) {
        Bank a = new Bank();
        a.rasioBunga();
        
        Bank b = new BankPribadi();
        b.rasioBunga();
        
        Bank c = new BankUmum();
        c.rasioBunga();
        
        Bank d = new BankPasar();
        d.rasioBunga();
        
        Bank e = new BankSyariah();
        e.rasioBunga();
    }
    
}
