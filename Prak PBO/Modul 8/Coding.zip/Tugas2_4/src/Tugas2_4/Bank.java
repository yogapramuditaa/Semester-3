
package Tugas2_4;

public class Bank {
    protected int rasioBunga(){
        int bungapertahun = 9;
        System.out.println("Bank Memiliki Bunga : " + bungapertahun + "%");
        return bungapertahun;
    }
    
}
