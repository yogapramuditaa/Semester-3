
package Tugas2_4;

public class BankPribadi extends Bank {
    protected int rasioBunga(){
        int bungapertahun = 7;
        System.out.println("Bank Pribadi Memiliki Bunga : " + bungapertahun + "%");
        return bungapertahun;
    }
    
}
