
package Tugas2_4;

public class BankUmum extends Bank{
    protected int rasioBunga(){
        int bungapertahun = 5;
        System.out.println("Bank Umum Memiliki Bunga : " + bungapertahun + "%");
        return bungapertahun;
    }
    
}
