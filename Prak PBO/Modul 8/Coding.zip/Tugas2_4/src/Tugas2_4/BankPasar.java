
package Tugas2_4;

public class BankPasar extends BankUmum{
    protected int rasioBunga(){
        int bungapertahun = 6;
        System.out.println("Bank Pasar Memiliki Bunga : " + bungapertahun + "%");
        return bungapertahun;
    }
    
}
