
package tugas6;

public class Segitiga extends BangunDatar {
    //Membuat instance variabel
    double alas;
    
}
