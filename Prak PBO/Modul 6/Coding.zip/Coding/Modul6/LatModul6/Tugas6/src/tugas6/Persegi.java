
package tugas6;

public class Persegi extends BangunDatar {
    //membuat instance variabel dengan type data double
    double sisi;
    
    //Membuat method dengan method overriding
    @Override
    double hitungLuas() {
        double hitungLuas = sisi*sisi;
        System.out.println("\n" + "Luas Persegi : " + hitungLuas);
        return hitungLuas;
    }
    
    //Membuat method dengan method overriding
    @Override
    double hitungKeliling() {
        double hitungKeliling = 4 * sisi;
        System.out.println("\n" + "Keliling Persegi : " + hitungKeliling);
        return hitungKeliling;
    }
    
}
