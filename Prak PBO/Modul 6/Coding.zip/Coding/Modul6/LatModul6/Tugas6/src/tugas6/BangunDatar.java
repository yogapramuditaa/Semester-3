
package tugas6;


public class BangunDatar {
    //membuat instance variabel dengan type data double
    double luas, keliling;
    
    //Membuat method hitungluas() & hitungKeliling()
    double hitungLuas() {
        System.out.println("Menghitung Luas Bangun datar");
        return 0;
    }
    
    double hitungKeliling(){
        System.out.println("Menghitung Keliling Bangun Datar");
        return 0;
    }
    
}
