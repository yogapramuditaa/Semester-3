
package tugas6;

public class Main {
    public static void main(String[] args) {
        //Membuat obejk bangun datar
        BangunDatar BD = new BangunDatar();
        //membuat objek persegi dan mengisi nilai properti
        Persegi persegi = new Persegi();
        persegi.sisi = 6;
        //membuat objek persegi panjang dan mengisi nilai properti
        PersegiPanjang persegipanjang = new PersegiPanjang();
        persegipanjang.panjang = 15;
        persegipanjang.lebar = 7;
        //membuat objek segitiga samakaki dan mengisi nilai properti
        SegitigaSamaKaki segitigasamakaki = new SegitigaSamaKaki();
        segitigasamakaki.sisiMiring = 20;
        segitigasamakaki.alas = 10;
        //membuat objek segitiga samasisi dan mengisi nilai properti
        SegitigaSamaSisi segitigasamasisi = new SegitigaSamaSisi();
        segitigasamasisi.sisi = 20;
//------------------------------------------------------------------------------
        //memanggil method luas dan keliling dengan memanggil objek diatas
        BD.hitungLuas();
        BD.hitungKeliling();
        System.out.println("-----------------");
        
        persegi.hitungLuas();
        persegi.hitungKeliling();
        
        segitigasamakaki.hitungLuas();
        segitigasamakaki.hitungKeliling();
        
        segitigasamasisi.hitungLuas();
        segitigasamasisi.hitungKeliling();
    }
    
}
