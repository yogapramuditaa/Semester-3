package tugas6;

public class PersegiPanjang extends BangunDatar {
    //membuat instance variabel dengan type data double
    double lebar;
    int panjang;
    
    //Membuat method dengan method overriding
    @Override
    double hitungLuas() {
        double hitungLuas = panjang * lebar;
        System.out.println("\n" + "Luas Persegi Panjang : " + hitungLuas);
        return hitungLuas;
    }
    
    //Membuat method dengan method overriding
    @Override
    double hitungKeliling() {
        double hitungKeliling = 2 * panjang + 2 * lebar;
        System.out.println("\n" + "Keliling Persegi panjang : " + hitungKeliling);
        return hitungKeliling;
    }
    
}