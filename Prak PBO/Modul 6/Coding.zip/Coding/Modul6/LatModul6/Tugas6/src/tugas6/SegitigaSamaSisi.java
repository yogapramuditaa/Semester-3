
package tugas6;


public class SegitigaSamaSisi extends Segitiga {
    //Membuat instance variabel dengan type data double
    double sisi;
    
    //membuat method dengan metode overriding
    @Override
    double hitungLuas() {
        double X = alas/2;
        //Mencari tinggi dengan menggunakan method Math.sqrt
        double tinggi = 0.5 * sisi * Math.sqrt(3);
        double hitungLuas = 0.5 * sisi * tinggi;
        System.out.println("\n" + "Luas Segitiga Sama Sisi : " + hitungLuas);
        return hitungLuas;
    }
    
    //Membuat method dengan metode overriding
    @Override
    double hitungKeliling() {
        double hitungKeliling = sisi + sisi + sisi;
        System.out.println("Keliling Segitiga Sama Sisi : " + hitungKeliling);
        return hitungKeliling;
    }
    
}
