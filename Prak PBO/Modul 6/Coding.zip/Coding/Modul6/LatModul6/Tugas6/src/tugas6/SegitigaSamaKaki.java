
package tugas6;


public class SegitigaSamaKaki extends Segitiga {
    //Membuat instance variabel dengan type data double
    double sisiMiring;
    
    //membuat method dengan metode overriding
    @Override
    double hitungLuas() {
        double X = alas/2;
        //Mencari tinggi dengan menggunakan method Math.sqrt
        double tinggi = Math.sqrt((sisiMiring*sisiMiring) - (X*X));
        double hitungLuas = 0.5 * alas * tinggi;
        System.out.println("\n" + "Luas Segitiga Sama Kaki : " + hitungLuas);
        return hitungLuas;
    }
    
    //Membuat method dengan metode overriding
    @Override
    double hitungKeliling() {
        double hitungKeliling = sisiMiring + sisiMiring + alas;
        System.out.println("Keliling Segitiga Sama Kaki : " + hitungKeliling);
        return hitungKeliling;
    }
    
}
