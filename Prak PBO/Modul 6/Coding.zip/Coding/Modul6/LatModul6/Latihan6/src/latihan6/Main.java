
package latihan6;

public class Main {
    public static void main(String[] args) {
        //Menampilkan hasil subclass motor.java
        Motor a = new Motor();
        a.display();
        
        System.out.println("------------------");
        
        //Menampilkan hasil subclass Mobil.java
        Mobil b = new Mobil();
        b.display();
    }
    
}
