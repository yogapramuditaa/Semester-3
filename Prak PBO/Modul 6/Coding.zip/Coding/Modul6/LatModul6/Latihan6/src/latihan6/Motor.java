
package latihan6;
//Ini adalah subclass

public class Motor extends Kendaraan {
//Variabel yang sama pada superclass dan memiliki nilai
    int berat = 100;

//variabeel unique yang tidak terdapat pada superclass
    String kecepatan = "90";
    
//methodmenampilkan hasil
    public void display() {
        System.out.println("Nama : " + this.Nama + "\n" +
                            "Buatan : " + this.Buatan + "\n" +
                            "Kecepatan : " + this.kecepatan + "\n" +
                            "Berat : " + berat + "Kg");
    }
}
