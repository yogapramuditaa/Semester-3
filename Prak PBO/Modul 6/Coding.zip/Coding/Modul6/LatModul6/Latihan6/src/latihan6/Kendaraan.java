
package latihan6;
//Ini adalah Superclass

public class Kendaraan {
//3 instance variabel
   String Nama = "Astrea"; 
   String Buatan = "Jepang";
   int berat = 400;
}
