package latihan6;
//Ini adalah subclass

public class Mobil extends Kendaraan {
//Variabel yang sama pada superclass dan memiliki nilai
    String Nama = "Brio";

//variabeel unique yang tidak terdapat pada superclass
    int kebisingan = 20;
    
//methodmenampilkan hasil
    public void display() {
        System.out.println("Nama : " + this.Nama + "\n" +
                            "Buatan : " + this.Buatan + "\n" +
                            "Kebisingan : " + this.kebisingan + "Hz" + "\n" +
                            "Berat : " + berat + "Kg");
    }
}