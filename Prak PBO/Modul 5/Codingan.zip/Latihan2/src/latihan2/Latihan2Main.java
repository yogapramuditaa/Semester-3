package latihan2;
public class Latihan2Main {
    public static void main(String[] args) {
        Latihan2 a = new Latihan2("Yoga Pramudita", "Tutorial Javascript Dasar");
        Latihan2 b = new Latihan2(1, 2020);
        Latihan2 c = new Latihan2(30000);
        a.display1();
        b.display2();
        c.display3();
        System.out.println();
        
        Latihan2 d = new Latihan2("Bintang", "Mengenal Javascript");
        Latihan2 e = new Latihan2(4, 2017);
        Latihan2 f = new Latihan2(25000);
        d.display1();
        e.display2();
        f.display3();
        System.out.println();
        
        Latihan2 g = new Latihan2("Pram", "Backend Developers");
        Latihan2 h = new Latihan2(2, 2019);
        Latihan2 i = new Latihan2(50000);
        g.display1();
        h.display2();
        i.display3();
        System.out.println();
        
        Latihan2 j = new Latihan2("Agus", "Jual Beli Saham");
        Latihan2 k = new Latihan2(5, 2019);
        Latihan2 l = new Latihan2(35000);
        j.display1();
        k.display2();
        l.display3();
        System.out.println();  
    }
}
