
package latihan2;

public class Latihan2 {
    String namaPengarang, judulBuku;
    int cetakanKe, tahunTerbit;
    double hargaJual;
    
    Latihan2(String namaPengarang, String judulBuku){
        this.namaPengarang = namaPengarang;
        this.judulBuku = judulBuku;
    }
    
    Latihan2(int cetakanKe, int tahunTerbit) {
        this.cetakanKe = cetakanKe;
        this.tahunTerbit = tahunTerbit;
    }
    
    Latihan2(double hargaJual) {
        this.hargaJual = hargaJual;
    }
    
    void display1(){
        System.out.println("Nama Pengarang : " + this.namaPengarang + "\n"
                            + "Judul Buku : " + this.judulBuku);
    }
    
    void display2(){
        System.out.println("Cetakan Ke : " + this.cetakanKe + "\n" +
                            "tahun Terbit : " + this.tahunTerbit);
    }
    
    void display3() {
        System.out.println("Harga Jual : Rp" + this.hargaJual);
    }
}
