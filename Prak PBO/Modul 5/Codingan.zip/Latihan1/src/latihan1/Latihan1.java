
package latihan1;


public class Latihan1 {
    String nama, nim, alamat;
    
    Latihan1() {
        this.nama = "Yoga Pramudita";
        this.alamat = "Sidowayah RT08 RW03, Rembang";
        this.nim = "L200200182";        
    }
    
    void display() {
        System.out.println("Nama : " + nama + "\n" +
                            "NIM : " + nim + "\n" +
                            "Alamat : " + alamat + "\n");
    }

    public static void main(String[] args) {
       Latihan1 i= new Latihan1();
       i.display();
    }
    
}
