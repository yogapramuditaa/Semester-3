
package tugas5;


public class TugasModul5 {
    String nama, nim, jurusan;
    
    TugasModul5(){
        this.nama = "Yoga Pramudita";
        this.nim = "L200200182";
        this.jurusan = "Teknik Informatika";
    }
    
    TugasModul5(String nama, String nim, String jurusan){
        this.nama = nama;
        this.nim = nim;
        this.jurusan = jurusan;
    }
    
    public void display() {
        System.out.println("Nama : " + nama + "\n" +
                            "NIM : " + nim + "\n" +
                            "Jurusan : " + jurusan);
    }
    
}
