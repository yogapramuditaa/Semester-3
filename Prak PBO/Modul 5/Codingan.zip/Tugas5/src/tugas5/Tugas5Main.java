
package tugas5;

public class Tugas5Main {
    public static void main(String[] args) {
        TugasModul5 i = new TugasModul5();
        i.display();
        
        System.out.println();
        
        TugasModul5 ii = new TugasModul5("Pram", "L20018363", "Teknik Informatika");
        ii.display();
   
    }
    
}
